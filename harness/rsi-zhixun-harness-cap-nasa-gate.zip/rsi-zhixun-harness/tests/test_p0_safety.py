"""NASA 门禁、状态迁移及真实续训/finish 接线的离线验证。"""
from pathlib import Path
import json
import math
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "harness")]
import contest_submission as submission
from src.harness.round_controller import acceptance, row_observation
from src.models.official_round import OfficialRound, nasa_score
from vendor.contest_baselines.data import flatten
from vendor.contest_baselines.model import Model


class NASATests(unittest.TestCase):
    def test_formula_sum_and_asymmetry(self):
        self.assertAlmostEqual(nasa_score([20, 20, 20], [7, 30, 20]), 2 * math.expm1(1))
        self.assertGreater(nasa_score([0], [13]), nasa_score([13], [0]))

    def test_absolute_gate_despite_rmse_gain(self):
        result = acceptance({"rmse": 100, "nasa": 2e6}, {"rmse": 90, "nasa": 1e6 + 1}, "regression")
        self.assertFalse(result["promote"])
        self.assertEqual(result["nasa_gate"]["reason"], "reject_nasa")

    def test_relative_gate_and_boundary(self):
        for candidate, passed in [(120, True), (120.001, False)]:
            result = acceptance({"rmse": 100, "nasa": 100}, {"rmse": 90, "nasa": candidate}, "regression")
            self.assertEqual(result["promote"], passed)
        self.assertTrue(acceptance({"rmse": 100, "nasa": 1e6}, {"rmse": 90, "nasa": 1e6}, "regression")["promote"])

    def test_invalid_or_missing_nasa_rejected(self):
        for value in [None, float("nan"), float("inf"), -1]:
            self.assertFalse(acceptance({"rmse": 100, "nasa": 10}, {"rmse": 90, "nasa": value}, "regression")["promote"])
        self.assertFalse(acceptance({"rmse": 100, "nasa": 10}, {"rmse": 90}, "regression")["promote"])

    def test_zero_parent_and_overflow(self):
        self.assertFalse(acceptance({"rmse": 100, "nasa": 0}, {"rmse": 90, "nasa": 1}, "regression")["promote"])
        self.assertTrue(math.isfinite(nasa_score([0], [1e9])))
        self.assertGreater(nasa_score([0], [1e9]), 1e6)

    def test_b_not_subject_to_nasa_gate(self):
        self.assertTrue(acceptance({"rmse": 100}, {"rmse": 90}, "regression")["promote"])


class RowTests(unittest.TestCase):
    def test_schema2_migration_and_actual_growth(self):
        state = row_observation({"n_train": 100}, 100, 20, 2)
        self.assertFalse(state["data_grew"])
        state = row_observation(state, 120, 22, 3)
        self.assertTrue(state["data_grew"])
        self.assertEqual(state["rows_history"], [{"round": 2, "train": 100, "validation": 20},
                                                {"round": 3, "train": 120, "validation": 22}])
        self.assertFalse(row_observation(state, 90, 23, 4)["data_grew"])

    def test_history_bounded(self):
        state = {}
        for i in range(1, 13):
            state = row_observation(state, i, 20, i)
        self.assertEqual(len(state["rows_history"]), 10)


class WiringTests(unittest.TestCase):
    def test_rejected_candidate_keeps_parent_finishes_and_saves_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            paths, _ = flatten([0.0] * 24)
            model = Model("regression", paths, [], np.zeros((32, 24)), np.full(32, 500.0))
            checkpoint = root / "checkpoint.npz"
            model.save(checkpoint)
            data = root / "public.jsonl"
            data.write_text("".join(json.dumps({"id": str(i), "inputs": [0.0] * 24, "answer": 0}) + "\n"
                                    for i in range(32)), encoding="utf-8")
            metrics = OfficialRound().evaluate(model, np.zeros((32, 24)), np.zeros(32))
            self.assertAlmostEqual(metrics["nasa"], 32 * math.expm1(130 / 10))
            self.assertAlmostEqual(metrics["nasa_raw"], 32 * math.expm1(500 / 10))
            finish = []
            def save_state(directory):
                shutil.copytree(directory, root / "saved", dirs_exist_ok=True)
            rnd = SimpleNamespace(task={"task": "regression"}, dataset_key="C", round_index=1,
                                  stage_id="C-test", max_output_tokens=256, history_ids=[], call_ids=["stub-call"],
                                  parent=SimpleNamespace(artifact_id="parent", declared_paths=lambda: ["checkpoint.npz"],
                                                         path=lambda p, root=None: checkpoint),
                                  data=SimpleNamespace(train_path=data, validation_path=data), history=lambda: [],
                                  model=lambda *args, **kw: SimpleNamespace(response={}),
                                  submit_candidate=lambda *args, **kw: self.fail("NASA-unsafe candidate uploaded"),
                                  save_state=save_state, finish=lambda **kw: finish.append(kw))
            with patch.object(submission, "WORKSPACE", root / "workspace"), \
                    patch.object(submission, "STATE_DIR", root / "empty"):
                submission.train(rnd)
            self.assertEqual(finish[0]["selected_artifact_id"], "parent")
            self.assertIn("reject_nasa", finish[0]["change_summary"])
            state = json.loads((root / "saved/harness_state.json").read_text(encoding="utf-8"))
            self.assertEqual(state["rows"], {"train": 32, "validation": 32})
            self.assertEqual(state["rows_history"][0]["round"], 1)
            self.assertIn("reject_nasa", (root / "workspace/audit-round-1.jsonl").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
