"""当前主分支控制器的九个离线兼容用例；不代表真实 LLM 覆盖率。"""
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.harness.round_controller import apply_verdict, extract_text, parse_verdict


class LLMDecisionTests(unittest.TestCase):
    def test_json(self):
        self.assertEqual(parse_verdict('{"decision":"train","epochs":2}')["action"], "train")

    def test_none(self):
        self.assertEqual(parse_verdict('{"decision":"none"}')["action"], "hold")

    def test_prose_fallback(self):
        self.assertIsNone(parse_verdict("Please continue training."))

    def test_invalid_action(self):
        self.assertIsNone(parse_verdict('{"decision":"delete"}'))

    def test_reasoning_content(self):
        response = {"choices": [{"message": {"content": "", "reasoning_content": '{"decision":"hold"}'}}]}
        self.assertEqual(parse_verdict(extract_text(response))["action"], "hold")

    def test_fenced_json(self):
        self.assertEqual(parse_verdict('```json\n{"decision":"train"}\n```')["action"], "train")

    def budget(self):
        return {"action": "finetune", "epochs": 3, "lr": 0.0015,
                "rule": "new_stage", "reason": "test", "signals": {}}

    def test_missing_verdict_keeps_rule(self):
        decision = apply_verdict(self.budget(), None, {}, 4)
        self.assertEqual((decision["epochs"], decision["model_action"]), (3, "unavailable"))

    def test_no_budget_increase(self):
        decision = apply_verdict(self.budget(), {"action": "train", "epochs": 1000}, {}, 4)
        self.assertEqual(decision["epochs"], 3)

    def test_hold_can_skip(self):
        decision = apply_verdict(self.budget(), {"action": "hold"}, {}, 4)
        self.assertEqual(decision["epochs"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
