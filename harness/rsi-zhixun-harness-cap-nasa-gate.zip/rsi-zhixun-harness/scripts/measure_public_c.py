"""测量固定策略在公开 C 验证集上的风险；不拟合、不搜索参数。"""
import argparse
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.harness.round_controller import clip_regression_prediction
from src.models.official_round import nasa_score, regression_metrics
from vendor.contest_baselines.data import read_dataset
from vendor.contest_baselines.model import Model, checkpoint_digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package", type=Path, help="C 公开数据包目录，包含 checkpoint.npz 与 public/validation.jsonl")
    args = parser.parse_args()
    checkpoint = args.package / "checkpoint.npz"
    model = Model.load(str(checkpoint))
    if model.meta["task"] != "regression" or len(model.meta["paths"]) != 24:
        raise ValueError("expected 24-feature C regression checkpoint")
    data = read_dataset(args.package / "public/validation.jsonl", "regression",
                        expected_paths=model.meta["paths"])
    y = data["y"]
    raw = model.predict(data["x"]).reshape(-1)
    result = {"purpose": "fixed-policy public validation measurement; no fitting",
              "checkpoint_sha256": checkpoint_digest(checkpoint), "validation_sha256": data["sha256"],
              "rows": len(y), "target_max": float(y.max()), "target_above_130": int(np.sum(y > 130)),
              "policies": {}}
    for name, pred in [("raw", raw),
                       ("existing_cap145", np.minimum(np.maximum(raw, 0), 145)),
                       ("requested_scale09_cap130", np.asarray([clip_regression_prediction(v, 24) for v in raw]))]:
        result["policies"][name] = {**regression_metrics(y, pred), "nasa": nasa_score(y, pred)}
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
