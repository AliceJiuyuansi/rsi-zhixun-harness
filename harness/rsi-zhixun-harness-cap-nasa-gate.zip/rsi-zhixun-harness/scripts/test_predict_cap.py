"""离线验证实际 predict 入口；也可在构建后的容器内直接运行。"""
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "harness")]
import contest_submission as submission


class PredictCapTests(unittest.TestCase):
    def answer(self, value, features=24, task="regression"):
        model = SimpleNamespace(
            meta={"task": task, "paths": list(range(features)), "classes": ["a", "b"]},
            predict=lambda x: np.asarray([[value]]) if task == "regression"
            else np.asarray([[0.2, 0.8]]))
        with patch.object(submission, "find_artifact_checkpoint", return_value=Path("fake.npz")), \
                patch.object(submission, "load_model_once", return_value=model):
            return submission.predict(SimpleNamespace(inputs=[0.0] * features), ROOT)

    def test_500_returns_130(self):
        answer = self.answer(500)["value"]
        self.assertEqual(answer, 130)
        print(f"predict: 24 features, model=500 -> value={answer}")

    def test_scale_below_cap(self):
        self.assertAlmostEqual(self.answer(100)["value"], 90)

    def test_nonnegative(self):
        self.assertEqual(self.answer(-10)["value"], 0)

    def test_b_unchanged(self):
        self.assertEqual(self.answer(500, 34)["value"], 500)

    def test_classification_unchanged(self):
        self.assertEqual(self.answer(500, 24, "classification")[0]["label"], "b")


if __name__ == "__main__":
    unittest.main(verbosity=2)
